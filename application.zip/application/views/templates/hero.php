<section id="home">
    <div id="hero" class="container-fluid no-gutters">
        <div class="row no-gutters">
            <div class="heading-wrap col-sm-12 col-md-6">
                <!-- <p class="typed2 typedss"></p> -->
                
                <p><b class="typed"></b><br><br>We make custom controls for your needs such as Heating controls, Cooling & Refrigeration controls, HVAC controls. For You we assemble electrical devices 
                    trough SMT and PTH productions...</p>

            </div>
            <div class="title-wrap col-sm-12 col-md-6">
                <!-- <div class="d-flex"> -->
                <!-- <p>We provide controls!</p> -->
                <div class="m-auto">

                    <img src="<?php echo base_url();?>/assets/img/display.jpg" alt="cccc">
                </div>
                <!-- </div> -->
                <!-- <p class="">Heating controls, Cooling & Refrigeration controls, HVAC controls</p> -->

                <!-- 
            <div class="dot-wrapper">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>-->
            </div>
            <div class="col-sm-12 moreproducts">

                <a href="#products">More products</a>
            </div>
        </div>
    </div>
</section>
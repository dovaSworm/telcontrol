<main>
    <section id="main">
        <div class="container bg-white">
            <div class="maindiv">
            <!-- <div class="w-100 d-flex mb-3 pattern">
                <div class="light"></div><div class="red"></div><div class="dark"></div>
            </div> -->
            <h1 class="text-center"><b>Telcontrol</b> offer to You Heating controls, Cooling & Refrigeration controls,
                        HVAC controls, Electrical devices assembling, instalation and technical support</h1>
            <!-- <div class="w-100 d-flex mt-3 pattern">
                <div class="light"></div><div class="red"></div><div class="dark"></div>
            </div> -->
                <div class="row">
                    <div class="main-menu flex-column d-flex justify-content-start col-12 col-lg-4">
                        <h3>&nbspCategories</h3>
                        <!-- <div class="w-100 d-flex pattern">
                <div class="light"></div><div class="red"></div><div class="dark"></div>
            </div> -->
                        <ul id="menu-ul">
                            <li><span></span>
                                <a data-toggle="collapse" data-parent="#menu-ul" href="#collapse-1" class="collapsed">
                                    Hydronic controls</a>
                                <ul id="collapse-1" class="collapse noSelect">
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=1">Pressurization
                                            controller</a>
                                    </li>
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=3">Expansion
                                            Board</a>
                                    </li>
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=2">Filter
                                            controller</a>
                                    </li>
                                </ul>
                            </li>
                            <li><span></span>
                                <a data-toggle="collapse" data-parent="#menu-ul" href="#collapse-2" class="collapsed">
                                    Compressed air treatment</a>
                                <ul id="collapse-2" class="collapse">
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=4">Refrigerated Air
                                            controller</a>
                                    </li>
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=5">Absorbtion dryer
                                            controlle</a>
                                    </li>
                                </ul>
                            </li>
                            <li><span></span>
                                <a data-toggle="collapse" data-parent="#menu-ul" href="#collapse-3" class="collapsed">
                                    HVAC controls</a>
                                <ul id="collapse-3" class="collapse">
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=13">DEK series</a>
                                    </li>
                                </ul>
                            </li>
                            <li><span></span>
                                <a data-toggle="collapse" data-parent="#menu-ul" href="#collapse-4" class="collapsed">
                                    Electrical heating controls</a>
                                <ul id="collapse-4" class="collapse">
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=10">Display GSM
                                            thermostat</a>
                                    </li>
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=6">On Board
                                            thermostat</a>
                                    </li>
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=7">Plug in
                                            thermostat</a>
                                    </li>
                                </ul>
                            </li>
                            <li><span></span>
                                <a data-toggle="collapse" data-parent="#menu-ul" href="#collapse-5" class="collapsed">
                                    Cooling and refrigeration</a>
                                <ul id="collapse-5" class="collapse">
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=12">REK digital
                                            controllers</a>
                                    </li>
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=11">LEK & TEK
                                            series</a>
                                    </li>
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=9">REK series</a>
                                    </li>
                                </ul>
                            </li>
                            <li><span></span>
                                <a data-toggle="collapse" data-parent="#menu-ul" href="#collapse-6" class="collapsed">
                                    Remote controls</a>
                                <ul id="collapse-6" class="collapse">
                                    <li><a class=""
                                            href="<?php echo base_url(); ?>products/?subcategory=8">OMD Telcom</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <p><i>*For prices please call or send an email.</i></p>
                        <div class="mt-4">
                            <p class="text-justify">Heating controls, Cooling & Refrigeration controls, HVAC controls, Electrical devices assembling and instalation, automatic production and testing system. A wide and complete range of products. A special feature is the capability to develop complete special solutions, customer oriented, helping the customers to realize their own ideas.
                            </p>
                        </div>
                    </div>